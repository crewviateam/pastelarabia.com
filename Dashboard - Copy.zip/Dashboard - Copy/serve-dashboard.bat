@echo off
powershell -ExecutionPolicy Bypass -File "%~dp0serve-dashboard.ps1"
pause
